import java.util.*;

public class Pass1Assembler {

    // Data structures
    static Map<String, Integer> SYMTAB = new LinkedHashMap<>();
    static List<String> LITTAB = new ArrayList<>();
    static List<Integer> POOLTAB = new ArrayList<>();
    static int LC = 0;  // Location Counter
    static int literalIndex = 0;  // Track literals for LTORG
    
    // Function to process the assembly code
    public static void processAssembly(List<String> inputLines) {
        POOLTAB.add(literalIndex);  // Add first pool index
        
        for (String line : inputLines) {
            String[] tokens = line.split(" ");
            String opcode = tokens[0];
            
            switch (opcode) {
                case "START":
                    LC = Integer.parseInt(tokens[1]);  // Set start address
                    System.out.println("LC set to " + LC);
                    break;
                    
                case "DS":  // Define storage
                    SYMTAB.put(tokens[0], LC);
                    LC += Integer.parseInt(tokens[1]);  // Reserve space
                    break;
                    
                case "DC":  // Define constant
                    SYMTAB.put(tokens[0], LC);
                    LC++;  // Constant occupies one location
                    break;
                    
                case "EQU":  // Set a symbol equal to an expression
                    String[] expression = tokens[1].split("\\+");
                    int address = SYMTAB.get(expression[0]) + Integer.parseInt(expression[1]);
                    SYMTAB.put(tokens[0], address);
                    break;
                    
                case "ORIGIN":  // Reset the LC
                    String[] originExpr = tokens[1].split("\\+");
                    LC = SYMTAB.get(originExpr[0]) + Integer.parseInt(originExpr[1]);
                    break;
                    
                case "LTORG":  // Assign addresses to literals
                    assignLiterals();
                    break;
                    
                case "END":  // End of program
                    assignLiterals();
                    break;
                    
                default:
                    if (opcode.equals("MOVER") || opcode.equals("MOVEM") || opcode.equals("ADD") || opcode.equals("PRINT")) {
                        if (tokens[2].startsWith("=")) {
                            LITTAB.add(tokens[2]);  // Add literal to LITTAB
                            literalIndex++;
                        }
                        LC++;
                    } else if (tokens[0].matches("[A-Za-z0-9]+:")) {
                        String label = tokens[0].replace(":", "");
                        SYMTAB.put(label, LC);
                    }
                    break;
            }
        }
    }

    // Function to assign addresses to literals when LTORG or END is encountered
    public static void assignLiterals() {
        for (int i = POOLTAB.get(POOLTAB.size() - 1); i < literalIndex; i++) {
            System.out.println("Assigning literal " + LITTAB.get(i) + " at address " + LC);
            LC++;
        }
        POOLTAB.add(literalIndex);  // Mark start of next literal pool
    }

    public static void main(String[] args) {
        List<String> inputLines = Arrays.asList(
            "START 100",
            "A DS 3",
            "L1 MOVER AREG, B",
            "ADD AREG, C",
            "MOVEM AREG, ='2'",
            "MOVEM AREG, ='3'",
            "D EQU A+1",
            "LTORG",
            "L2 PRINT D",
            "MOVEM AREG, ='4'",
            "MOVEM AREG, ='5'",
            "ORIGIN L2+1",
            "LTORG",
            "B DC '19'",
            "C DC '17'",
            "END"
        );

        processAssembly(inputLines);

        // Print symbol table
        System.out.println("\nSYMTAB:");
        for (Map.Entry<String, Integer> entry : SYMTAB.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }

        // Print literal table
        System.out.println("\nLITTAB:");
        for (int i = 0; i < LITTAB.size(); i++) {
            System.out.println(LITTAB.get(i));
        }

        // Print pool table
        System.out.println("\nPOOLTAB:");
        for (int index : POOLTAB) {
            System.out.println(index);
        }
    }
}

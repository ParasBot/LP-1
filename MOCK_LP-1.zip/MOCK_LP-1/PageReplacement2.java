import java.util.*;

public class PageReplacement2 {
    
    // Method to simulate FIFO page replacement
    public static void fifoPageReplacement(int[] pages, int numFrames) {
        Set<Integer> frameSet = new HashSet<>();
        Queue<Integer> frameQueue = new LinkedList<>();
        int pageFaults = 0;

        System.out.println("FIFO Page Replacement:");
        for (int page : pages) {
            if (!frameSet.contains(page)) {
                if (frameQueue.size() == numFrames) {
                    int removedPage = frameQueue.poll();
                    frameSet.remove(removedPage);
                }
                frameQueue.add(page);
                frameSet.add(page);
                pageFaults++;
                System.out.println("Page fault for page: " + page);
            } else {
                System.out.println("No page fault for page: " + page);
            }
        }
        System.out.println("Total page faults (FIFO): " + pageFaults);
    }

    // Method to simulate Optimal page replacement
    public static void optimalPageReplacement(int[] pages, int numFrames) {
        Set<Integer> frameSet = new HashSet<>();
        int pageFaults = 0;

        System.out.println("\nOptimal Page Replacement:");
        for (int i = 0; i < pages.length; i++) {
            if (!frameSet.contains(pages[i])) {
                if (frameSet.size() < numFrames) {
                    frameSet.add(pages[i]);
                } else {
                    int furthestPage = getFurthestPage(pages, frameSet, i);
                    frameSet.remove(furthestPage);
                    frameSet.add(pages[i]);
                }
                pageFaults++;
                System.out.println("Page fault for page: " + pages[i]);
            } else {
                System.out.println("No page fault for page: " + pages[i]);
            }
        }
        System.out.println("Total page faults (Optimal): " + pageFaults);
    }

    // Helper method to find the page that will not be used for the longest period of time
    private static int getFurthestPage(int[] pages, Set<Integer> frameSet, int currentIndex) {
        int furthestIndex = -1;
        int furthestPage = -1;

        for (int page : frameSet) {
            int index = findNextUse(pages, page, currentIndex);
            if (index > furthestIndex) {
                furthestIndex = index;
                furthestPage = page;
            }
        }
        return furthestPage;
    }

    // Helper method to find the next use of a page
    private static int findNextUse(int[] pages, int page, int currentIndex) {
        for (int i = currentIndex; i < pages.length; i++) {
            if (pages[i] == page) {
                return i;
            }
        }
        return Integer.MAX_VALUE; // If the page is not found in the future
    }

    public static void main(String[] args) {
        // Example input
        int[] pages = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
        int numFrames = 3;

        fifoPageReplacement(pages, numFrames);
        optimalPageReplacement(pages, numFrames);
    }
}

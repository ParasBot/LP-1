import java.io.*;
import java.util.*;

class Assembler {
    static class Instruction {
        String opcode;
        List<String> operands;

        Instruction(String opcode, List<String> operands) {
            this.opcode = opcode;
            this.operands = operands;
        }
    }

    static Map<String, String> opcodeTable = new HashMap<>();
    static Map<String, String> symTab = new HashMap<>();
    static Map<String, String> litTab = new HashMap<>();
    
    static void initializeOpcodeTable() {
        opcodeTable.put("IS", "Instruction");
        opcodeTable.put("AD", "Address");
        opcodeTable.put("DL", "Decl");
        // Add other opcodes as needed
    }

    static void readSymTab(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(" ");
            String symbol = parts[0];
            String address = parts[2];
            symTab.put(symbol, address);
        }
        reader.close();
    }

    static void readLitTab(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(" ");
            String literal = parts[0];
            String address = parts[1];
            litTab.put(literal, address);
        }
        reader.close();
    }

    static List<Instruction> readIntermediate(String filename) throws IOException {
        List<Instruction> intermediate = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("\\)");
            for (String part : parts) {
                if (!part.trim().isEmpty()) {
                    String trimmed = part.trim().replaceAll("[()]", "").trim();
                    String[] tokens = trimmed.split(",");
                    if (tokens[0].startsWith("IS")) {
                        String opcode = tokens[0];
                        List<String> operands = new ArrayList<>();
                        for (int i = 1; i < tokens.length; i++) {
                            operands.add(tokens[i]);
                        }
                        intermediate.add(new Instruction(opcode, operands));
                    }
                }
            }
        }
        reader.close();
        return intermediate;
    }

    static void passTwo(List<Instruction> intermediate) {
        System.out.println("Pass-II Output:");
        for (Instruction instr : intermediate) {
            StringBuilder outputLine = new StringBuilder();
            outputLine.append(instr.opcode).append(" ");
            for (String operand : instr.operands) {
                if (operand.startsWith("S")) {
                    // Symbol reference
                    String symbol = operand.substring(1);
                    outputLine.append(symTab.get(symbol)).append(" ");
                } else if (operand.startsWith("L")) {
                    // Literal reference
                    String literal = operand.substring(1);
                    outputLine.append(litTab.get(literal)).append(" ");
                } else {
                    outputLine.append(operand).append(" "); // Direct operand
                }
            }
            System.out.println(outputLine.toString().trim());
        }
    }

    public static void main(String[] args) {
        try {
            initializeOpcodeTable();
            readSymTab("Symtab.txt");
            readLitTab("Littab.txt");
            List<Instruction> intermediate = readIntermediate("Intermediate.txt");
            passTwo(intermediate);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
